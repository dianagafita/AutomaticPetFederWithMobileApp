//
//  petfeederApp.swift
//  petfeeder
//
//  Created by Diana Gafița on 26.07.2023.
//

import SwiftUI

@main
struct petfeederApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
