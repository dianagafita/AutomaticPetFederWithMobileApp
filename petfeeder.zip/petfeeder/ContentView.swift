import SwiftUI
import Combine
struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack {
                Image(systemName: "pawprint")
                Text("Welcome to Happy Pet")
                    .font(.largeTitle)
                    .padding()
                NavigationLink("Device Management", destination: DeviceView())
                    .foregroundColor(.mint)
            }
            .navigationBarTitle("Happy Pet", displayMode: .large)
        }
    }

    struct DeviceView: View {
        @ObservedObject private var sensorModel1 = SensorViewModel(sensorURL: URL(string: "http://192.168.0.38/read1")!, maxValue: 400.0)
        @ObservedObject private var sensorModel2 = SensorViewModel(sensorURL: URL(string: "http://192.168.0.38/read2")!, maxValue: 200.0)
        @ObservedObject private var sensorModel3 = SensorViewModel(sensorURL: URL(string: "http://192.168.0.38/read3")!, maxValue: 1000.0)
        @ObservedObject private var sensorModel4 = SensorViewModel(sensorURL: URL(string: "http://192.168.0.38/read4")!, maxValue: 600.0)

        @State private var isWaterPumpOn = false
        @State private var isServoOn = false
        @State private var isLoading = true
        @State private var isNotificationShown = false
        @State private var isSystemStarted = false
        @State private var isSystemStarted1 = false
        @State private var isSystemStarted2 = false
        @State private var isSystemStarted3 = false

        var body: some View {
            VStack {

                SensorView(sensorModel: sensorModel1, label: "Water Bowl Weight: ")                    .padding(.top, -100)

                SensorView(sensorModel: sensorModel2, label: "Food Container Weight: ")                    .padding()

                SensorView(sensorModel: sensorModel3, label: "Food Bowl  weight: ")                    .padding()

                SensorView(sensorModel: sensorModel4, label: "Container Water Level: ")                    .padding(.top, -10)

                VStack(spacing:5){
                    HStack(spacing:5)
                    {
                        Button(isWaterPumpOn ? "STOP" : "Fill the water bowl") {
                            toggleWaterPump()
                        }
                        .buttonStyle(RealisticButtonStyle())
                        .frame(width: 180, height: 10)
                        .padding()
                        Button(isServoOn ? "STOP" : "Fill the food bowl") {
                            servostart()
                        }
                        .buttonStyle(RealisticButtonStyle())
                        .frame(width: 170, height: 10)
                        .padding()                    }
                    Button("Refresh All") {
                        refreshAllSensors()
                    }
                    .buttonStyle(RealisticButtonStyle())
                    .frame(width: 150, height: 10)
                    .padding(.top, 40)

                    .alert(isPresented: $isNotificationShown) {
                        Alert(
                            title: Text("Add More Water"),
                            message: Text("There is no more water in the container. Please add more water."),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                    .onReceive(sensorModel4.$sensorValue, perform: { newValue in
                        if !isSystemStarted {

                            isSystemStarted = true
                            return
                        }
                        DispatchQueue.main.async {
                            let numericValue = Float(newValue) ?? 0
                            if numericValue < 400 {
                                isNotificationShown = true
                            }
                        }
                    })
                    .alert(isPresented: $isNotificationShown) {
                        Alert(
                            title: Text("Add more food"),
                            message: Text("There is no more food in the container. Please add more food."),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                    .onReceive(sensorModel2.$sensorValue, perform: { newValue in
                        if !isSystemStarted1 {
                            isSystemStarted = true
                            return
                        }
                        DispatchQueue.main.async {
                            let numericValue = Float(newValue) ?? 0
                            if numericValue < 500 {
                                isNotificationShown = true
                            }
                        }
                    })
                }
                .alert(isPresented: $isNotificationShown) {
                    Alert(
                        title: Text("Add more water"),
                        message: Text("Fill the water bowl."),
                        dismissButton: .default(Text("OK"))
                    )
                }
                .onReceive(sensorModel1.$sensorValue, perform: { newValue in
                    if !isSystemStarted1 {

                        isSystemStarted2 = true
                        return
                    }
                    DispatchQueue.main.async {
                        let numericValue = Float(newValue) ?? 0
                        if numericValue < 100 {
                            isNotificationShown = true
                        }
                    }
                })
                .alert(isPresented: $isNotificationShown) {
                    Alert(
                        title: Text("Add more food"),
                        message: Text("Fill the food bowl."),
                        dismissButton: .default(Text("OK"))
                    )
                }
                .onReceive(sensorModel3.$sensorValue, perform: { newValue in
                    if !isSystemStarted1 {

                        isSystemStarted3 = true
                        return
                    }
                    DispatchQueue.main.async {
                        let numericValue = Float(newValue) ?? 0
                        if numericValue < 100 {
                            isNotificationShown = true
                        }
                    }
                })
                .padding()
            }}

        func refreshAllSensors() {
            sensorModel1.setupDataRetrieval()
            sensorModel2.setupDataRetrieval()
            sensorModel3.setupDataRetrieval()
            sensorModel4.setupDataRetrieval()
        }
        func toggleWaterPump() {
            let pumpCommand = isWaterPumpOn ? "off" : "on"
            let waterPumpURL = URL(string: "http://192.168.0.38/waterpump/\(pumpCommand)")!
            URLSession.shared.dataTask(with: waterPumpURL) { _, _, error in
                if let error = error {
                    print("Error toggling water pump: \(error)")
                } else {
                    print("Water pump toggled \(pumpCommand)")
                    isWaterPumpOn.toggle()
                }
            }.resume()
        }
        func servostart() {
            let servo = isServoOn ? "off" : "on"
            let servoURL = URL(string: "http://192.168.0.38/servo/\(servo)")!
            URLSession.shared.dataTask(with: servoURL) { _, _, error in
                if let error = error {
                    print("Error starting servo: \(error)")
                } else {
                    print("Servo started  \(servo)")
                    isServoOn.toggle()
                }
            }.resume()
        }
    }
    struct RealisticButtonStyle: ButtonStyle {
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .padding()
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: 4)
                        .fill(configuration.isPressed ? Color.mint.opacity(0.4) : Color.mint)
                        .shadow(color: .gray, radius: 3, x: 0, y: 2)
                )
                .foregroundColor(.white)
                .font(.headline)
                .animation(.easeInOut(duration: 0.2))
        }
    }

    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
    struct SensorView: View {
        @ObservedObject var sensorModel: SensorViewModel
        let label: String
        private var lineColor: Color {
            let value = sensorModel.progress / sensorModel.maxValue
            let red = min(1.0, 2.0 * (1.0 - value))
            let green = min(1.0, 2.0 * value)
            return Color(red: red, green: green, blue: 0.0)
        }
        var body: some View {
            VStack {
                Text(label + ":")
                    .font(.headline)
                Text(sensorModel.sensorValue)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                if sensorModel.isLoading {
                ProgressView("Loading...")
                            }
                else {
                ProgressView(value: sensorModel.progress, total: sensorModel.maxValue)
                    .padding()
                    .accentColor(lineColor)
            }
            }
            .padding(.top, -10)
            .onAppear {
                sensorModel.setupDataRetrieval()
            }
            .alert(item: $sensorModel.errorModel) { errorModel in
                Alert(
                    title: Text("Error"),
                    message: Text(errorModel.message),
                    primaryButton: .default(Text("Retry"), action: {
                        sensorModel.setupDataRetrieval()
                    }),
                    secondaryButton: .cancel(Text("OK"))
                )
            }
        }
    
}

    struct ErrorModel: Identifiable, Error {
        let id = UUID()
        let message: String
    }
    class SensorViewModel: ObservableObject {
        @Published var sensorValue: String = ""
        @Published var progress: Double = 0.0
        @Published var errorModel: ErrorModel?
        @Published var isLoading: Bool = false
        fileprivate var cancellables: Set<AnyCancellable> = []
        private let sensorURL: URL
        let maxValue: Double
        init(sensorURL: URL, maxValue: Double) {
            self.sensorURL = sensorURL
            self.maxValue = maxValue
        }
        func setupDataRetrieval() {
            isLoading = true

            Timer.publish(every:  60, on: .main, in: .common)
                .autoconnect()
                .flatMap { _ in
                    var request = URLRequest(url: self.sensorURL)
                    request.timeoutInterval = 50
                    return URLSession.shared.dataTaskPublisher(for: request)
                        .retry(3)
                        .map(\.data)
                        .compactMap { data in
                            String(data: data, encoding: .utf8)
                        }
                        .replaceError(with: "Error fetching data")
                        .receive(on: DispatchQueue.main)
                }
                .sink { [weak self] sensorValue in
                    if sensorValue == "Error fetching data" {
                        print("Error: Unable to fetch data from sensor.")
                    } else {

                        print("Connection and data retrieval successful")
                    }
                    self?.isLoading = false

                    self?.sensorValue = sensorValue
                    let numericValue = Float(sensorValue) ?? 0
                    let scaledValue = Double(numericValue)
                    self?.progress = max(scaledValue, 0.0)
                    print("Sensor value received and processed: \(self?.sensorValue ?? "")")
                    print("Data retrieval and processing complete")
                }
                .store(in: &cancellables)
        }
    }
}

